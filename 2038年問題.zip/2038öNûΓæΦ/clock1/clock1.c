#include <stdio.h>
#include <time.h>
#include <Windows.h>
void main()
{
    time_t i;
    while(1)
    {
        i = time(NULL);
        printf("%d\n\n", i);
        Sleep(1000);
    }
}