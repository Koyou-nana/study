#include <stdio.h>
#include <time.h>
#include <Windows.h>
void main()
{
    time_t i;
    struct tm *now;
    while(1)
    {
        i = time(NULL);
        now = localtime(&i);
        printf("%d�N%d��%d�� %2d:%2d:%2d\n\n", (now->tm_year)+1900, (now->tm_mon)+1, now->tm_mday, now->tm_hour, now->tm_min, now->tm_sec);
        Sleep(1000);
    }
}