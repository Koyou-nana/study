#include <stdio.h>
#include <time.h>

void main()
{
    time_t a, b, c;
    a = 0;
    b = 0;
    while(1)
    {
        c = a - b;
        if (c >= 3)
        {
            printf("HelloWorld!\n");
            b = time(NULL);
        }
        a = time(NULL);
    }
}