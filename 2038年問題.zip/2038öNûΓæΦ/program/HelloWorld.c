#include <stdio.h>
#include <time.h>

void main()
{
    time_t a, b, c;
    int i = 0;
    a = 0;
    b = 0;
    while(1)
    {
        c = a - b;
        if (c >= 3)
        {
            printf("%d HelloWorld!\n\n", i++);
            b = time(NULL);
        }
        a = time(NULL);
    }
}